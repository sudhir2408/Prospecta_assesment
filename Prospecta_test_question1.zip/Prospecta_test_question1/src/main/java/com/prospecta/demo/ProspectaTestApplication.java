package com.prospecta.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProspectaTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProspectaTestApplication.class, args);
	}

}
